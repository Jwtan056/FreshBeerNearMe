//The objective of part 1 is to download the location audit file and scrape the links for each places.

//Import all the necessary functions
import puppeteer from "puppeteer";
import { createRequire } from 'module';
import { fileURLToPath } from "node:url";
import { dirname } from 'path';

const require = createRequire(import.meta.url);

const fs = require("fs");

//Read line by line
const readline = require('readline');

//Set the download path
const express = require("express")
const app = express();

const username = "tanjunweitest@gmail.com"
const password = "A1b2c3d4e5f6*"

//Setting the Download path for all the files
const path = require('path');
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
//You can change download folder to any name as long as it exists in the folder
const downloadPath = path.join(__dirname, 'Downloads')

const getFiles = async () => {
  try {
    if (!fs.existsSync(downloadPath)) {
      fs.mkdirSync(downloadPath);
    }
  } catch (err) {
    console.error(err);
  }  

  // Start a Puppeteer session with:
  // - a visible browser (`headless: false` - easier to debug because you'll see the browser in action)
  // - no default viewport (`defaultViewport: null` - website page will be in full width and height)

  //To run the browser in google chrome
  const browser = await puppeteer.launch( { headless: false,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\Chrome.exe'}) //Gotta change based on where the location of the chrome ios stored

  // Open a new page
  const page = await browser.newPage();
  await page.goto("https://app.binarybeer.io", {
    waitUntil: "domcontentloaded",
  });

  //Set download location
  const client = await page.target().createCDPSession()
  await client.send('Page.setDownloadBehavior', {
    behavior: 'allow',
    downloadPath
  })

  //Waiting for the website to finish loading the login page first
  await Promise.all([
    page.waitForNavigation({waitUntil: 'networkidle2'})
  ]);

  //Input the details of the binary beer account
  await page.type('#root > section > div.sc-pyfCe.doZzTt > div > form > div:nth-child(2) > input', username);
  await page.type('#root > section > div.sc-pyfCe.doZzTt > div > form > div:nth-child(3) > input', password);
  await page.click('#root > section > div.sc-pyfCe.doZzTt > div > form > button');
  
  //Wait for the website to log the user in
  await Promise.all([
    page.waitForNavigation({waitUntil: 'networkidle2'})
  ]);

  //Go to the location audit page
  await page.goto('https://app.binarybeer.io/reports/location-audit', {waitUntil: 'domcontentloaded'})

  //Wait for the site to load
  await Promise.all([
    page.waitForNavigation({waitUntil: 'networkidle2'})
  ]);

  //Make the page wait for 4000 miliseconds before continuing
  await page.waitForTimeout(4000);

  //Search for a button call csv then click on it
  const [button] = await page.$x("//button[contains(., 'CSV')]");
  await button.click();
  console.log("Location Audit.csv Download Complete")

  //Getting the last page number
  const endpageNo = await page.evaluate(() => {
    return document.querySelector('.-totalPages').innerText;
 });

  var PageNo = 1;
  var AllLinks = [];
  //This loop will loop through the pages while incrementing PageNo. Once it hits the last page it will break the loop
  do {
    //Some minor editing where i remove the headers and the useless links before adding it to the overall
    const hrefs = await page.$$eval('a', as => as.map(a => a.href));
    hrefs.shift();
    hrefs.pop();
    hrefs.pop();
    hrefs.pop();
    AllLinks = AllLinks.concat(hrefs);

    //Finding the next button in the page
    const [button] = await page.$x("//button[contains(., 'Next')]");    
    if (PageNo != endpageNo) {
      await button.click();
      PageNo =  PageNo + 1;
    }
    else {
      break;
    }
  }
  while (true);

console.log(AllLinks);

  //Creating a file to store all the links
  const writeStream = fs.createWriteStream('Downloads/VenueLinks.csv');
  writeStream.write(AllLinks.join(',\n'));
  console.log("VenueLinks.csv has been created.");

  // Close the browser
  await browser.close();
};

// Start the scraping
getFiles();
