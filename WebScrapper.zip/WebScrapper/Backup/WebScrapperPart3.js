//The objectives of part 3 is to insert the data into the database

//Import all the necessary functions
import { createRequire } from 'module';
import { fileURLToPath } from "node:url";
import { dirname } from 'path';

const require = createRequire(import.meta.url);

//For connection to mongodb
const {MongoClient} = require('mongodb');

const fs = require("fs");

//Read line by line
const readline = require('readline');

//Set the download path
const express = require("express")
const app = express();

//Setting the Download path for all the files
const path = require('path');
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

//Slp Function
function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

//Update function to update the documents
const uri = "mongodb+srv://phuasiqi:Password123@fyp-test.rv5527m.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri);

async function updatebeer(kegid, freshness, temp){
  const result = await client.db("BeerSystem").collection("Keg")
                      .updateOne({ _id: kegid }, 
                                  { $set: {freshness : freshness, temperature: temp} }, 
                                  { upsert: true });
  console.log(`${result.matchedCount} document(s) matched the query criteria.`);

  if (result.upsertedCount > 0) {
      console.log(`One document was inserted with the id ${result.upsertedId._id}`);
  } else {
      console.log(`${result.modifiedCount} document(s) was/were updated.`);
  }
}

//You can change download folder to any name as long as it exists in the folder
var testFolder = path.join(__dirname, 'Downloads', 'LocationFiles')

var FileList = []

fs.readdirSync(testFolder).forEach(file => {
  FileList.push(file);
});

console.log(FileList);

for(let counter = 0; counter < FileList.length; counter++){
  const ReadFile = [];
  try {
    const coolPath = path.join(testFolder, FileList[counter]);
    const readStream = fs.createReadStream(coolPath);
  
    //Reading of the csv file .replace will replace \n with ,
    readStream.on('data', (chunk) => {
        console.log(FileList[counter] + ' successfully opened');
        chunk = chunk + '';
        chunk = chunk.replace(/\r?\n|\r/g, ",");
        ReadFile.push(
            ...chunk.split().map((line) => {
                return line.split(',');
            })
        );
    });
  
    readStream.on('error', (err) => {
        console.log(err);
        console.log('error found');
    });
  
    readStream.on('end', () => {
        console.log('%s has successfully been read.', FileList[counter]);
    });
  }
  catch (error) {
    console.error(`Could not read ` + FileList[counter]);
  }

  await sleep(100);
  for(let i = 0; i < 11; i++){
    ReadFile[0].shift();
  }
  await sleep(100);
  
  do{
    if(ReadFile[0].length == 1)
    {
      break;
    }

    else{
      console.log('Keg id - ' + ReadFile[0][3]);
      console.log('Freshness - ' + ReadFile[0][6]);
      console.log('Temperature - ' + ReadFile[0][4]);
      
      try {
        // Connect to the MongoDB cluster
        await client.connect();
  
        // Make the appropriate DB calls
        await updatebeer(ReadFile[0][3].slice(1, -1), ReadFile[0][6].slice(1, -1), ReadFile[0][4].slice(1, -1));
  
      } catch (e) {
          console.error(e);
      } finally {
          await client.close();
      }

      for(let j = 0; j < 11; j++){
        ReadFile[0].shift();
      }
    }
    
  } while(true)
}
