//The objectives of part 2 is to download all the files from the individual places

//Import all the necessary functions
import puppeteer from "puppeteer";
import { createRequire } from 'module';
import { fileURLToPath } from "node:url";
import { dirname } from 'path';

const require = createRequire(import.meta.url);

const fs = require("fs");

//Read line by line
const readline = require('readline');

//Set the download path
const express = require("express")
const app = express();

const username = "tanjunweitest@gmail.com"
const password = "A1b2c3d4e5f6*"

//Setting the Download path for all the files
const path = require('path');
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
//You can change download folder to any name as long as it exists in the folder
var downloadPath = path.join(__dirname, 'Downloads')

const getFiles = async () => {
  var counter = 0; //Counter to count through the number of places

  //Read VenueLinks csv
  //Current bug. It became a double array but small thing
  var ReadFile = [];
  try {
    const coolPath = path.join(downloadPath, 'VenueLinks.csv');
    const readStream = fs.createReadStream(coolPath);
  
    //Reading of the csv file .replace will replace \n with ,
    readStream.on('data', (chunk) => {
        console.log('VenueLinks.csv successfully opened');
        chunk = chunk + '';
        chunk = chunk.replace(/\r?\n|\r/g, "");
        ReadFile.push(
            ...chunk.split().map((line) => {
                return line.split(',');
            })
        );
    });
  
    readStream.on('error', (err) => {
        console.log(err);
        console.log('error found');
    });
  
    readStream.on('end', () => {
        console.log('Finished reading Location Audit csv file');
    });

  }
  catch (error) {
    console.error(`Could not read Location Audit.csv`);
  }
  
  //Create New Folder call LocationFiles in downloadPath
  //This will be where i store all the location of the files
  downloadPath = path.join(downloadPath, 'LocationFiles');
  try {
    if (!fs.existsSync(downloadPath)) {
      fs.mkdirSync(downloadPath);
    }

    //If download failed somewhere. Continue the download
    else {
      counter = fs.readdirSync(downloadPath).length;
      console.log("Continuing Download");
    }
  } catch (err) {
    console.error(err);
  }  

  // Start a Puppeteer session with:
  // - a visible browser (`headless: false` - easier to debug because you'll see the browser in action)
  // - no default viewport (`defaultViewport: null` - website page will be in full width and height)

  //To run the browser in google chrome
  const browser = await puppeteer.launch( { headless: false,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\Chrome.exe'}) //Gotta change based on where the location of the chrome ios stored

  // Open a new page
  const page = await browser.newPage();
  await page.goto("https://app.binarybeer.io", {
    waitUntil: "domcontentloaded",
  });

  //Set download location
  const client = await page.target().createCDPSession()
  await client.send('Page.setDownloadBehavior', {
    behavior: 'allow',
    downloadPath
  })

  //Waiting for the website to finish loading the login page first
  await Promise.all([
    page.waitForNavigation({waitUntil: 'networkidle2'})
  ]);

  //Input the details of the binary beer account
  await page.type('#root > section > div.sc-pyfCe.doZzTt > div > form > div:nth-child(2) > input', username);
  await page.type('#root > section > div.sc-pyfCe.doZzTt > div > form > div:nth-child(3) > input', password);
  await page.click('#root > section > div.sc-pyfCe.doZzTt > div > form > button');
  
  //Wait for the website to log the user in
  await Promise.all([
    page.waitForNavigation({waitUntil: 'networkidle2'})
  ]);

  var timer = 7000; //7 Secs
  do {
    var FileDownloaded = false;
    while(FileDownloaded == false){
      //Go to the different pages
      await page.goto(ReadFile[0][counter], {waitUntil: 'domcontentloaded'})
      //Make the page wait for 3 seconds before continuing
      await page.waitForTimeout(3000);

      //This will change the button value to another value so that it wont affect the button with the same value later on
      /*
      const [button] = await page.$x("//button[contains(., 'Last 7 days')]");    
      await button.click();
      await page.waitForTimeout(1000);
      const [button4] = await page.$x("//span[contains(., 'Last 3 days')]");
      await button4.click();
      await page.waitForTimeout(3000);
      */

      //Click the Download csv button
      try{
        await page.click('#root > div > div.sc-jZatrU.eBXnkE > div.sc-uhnfH.jEqHYu > div.sc-pyfCe.doZzTt > div:nth-child(1) > div.sc-fHSyak.fXAaA-D > div.sc-pyfCe.doZzTt > section > div:nth-child(12) > button:nth-child(2) > div > svg > path');
        FileDownloaded = true;
      }
      catch (err){
        try{
          await page.click('#root > div > div.sc-jZatrU.eBXnkE > div.sc-uhnfH.jEqHYu > div.sc-pyfCe.doZzTt > div:nth-child(1) > div.sc-fHSyak.fXAaA-D > div.sc-pyfCe.doZzTt > section > div:nth-child(9) > button:nth-child(2) > div > svg > path');
          FileDownloaded = true;
        }

        catch(err){
          //If theres error, i will go and take the new selector value and stack it in this try catch statement
          console.log("There seems to be an error in this site.");
          console.log("Reloading the page to try again.");
          await page.waitForTimeout(2000);
          FileDownloaded = false;
        }
      }
    }
    
    //Click the Date Range 
    const button5 = await page.$x("//button[contains(., 'Last 7 days')]");    
    await button5[1].click();
    await page.waitForTimeout(2000);
    const [button2] = await page.$x("//span[contains(., 'Last 24 hours')]");    
    await button2.click();
    await page.waitForTimeout(3000);
    const [button3] = await page.$x("//button[contains(., 'Download')]");    
    await button3.click();
    await page.waitForTimeout(timer);

    if(counter % 20 === 0){
      console.log((((counter + 1)/ReadFile[0].length ) * 100).toFixed(3) + "% done")
    }

    counter = counter + 1;
    if(counter == ReadFile[0].length){
      console.log("100% done. Download completed.");
      break;
    }
  }
  while (true);

  // Close the browser
  await browser.close();
};

// Start the scraping
getFiles();
